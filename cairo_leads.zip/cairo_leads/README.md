# Cairo businesses with no website listed

## Web dashboard

Install the updated dependencies once, then launch from this folder:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1
```

Open http://127.0.0.1:8501. Choose a backend, districts, categories and limits in the sidebar, then click **Start Scraping**. Enter a Places API key in the password field or use `GOOGLE_MAPS_API_KEY`. Playwright also needs the one-time Chromium installation shown below. For subsequent launches, only the final command is needed; all scraping controls are in the dashboard.

The dashboard runs one background worker per browser session and polls progress once per second using [Streamlit fragments](https://docs.streamlit.io/develop/api-reference/execution-flow/st.fragment). **Stop / Cancel** interrupts in-flight work and closes the client/browser; completed observations stay available. Filters remain editable during a run and affect both table and downloads. Unchecking **Only No Website** includes website-bearing records. Each new run replaces that session's previous results. Download before starting another run or refreshing/closing the session. Results are held in memory, not checkpointed to disk by the dashboard. Closing the tab is not a cancellation command: stop the run first. An orphaned run finishes within its configured limits; shutting down the server ends it.

CSV and formatted Excel downloads contain all fields. Excel stores phone numbers and user-controlled strings as literal text. Counters describe deduplicated businesses before display filters; “Verified Phone Numbers” means valid Egyptian number format, not confirmed reachability. The dashboard uses a broader approximate Greater Cairo envelope that includes Dokki and Sheikh Zayed; CLI defaults are unchanged. The password widget retains its value within the session and is never placed in logs or exports. Run locally; this app does not implement multiuser authentication.

Dashboard tests cover rendering, filter controls, API-key validation, background cancellation and safe Excel cells. They do not establish live Google extraction compatibility.

Python 3.11+ asynchronous pipeline with two interchangeable backends. `places` is the default and has structured fields; `playwright` reads the Maps interface and requires ongoing selector maintenance.

## Install

From this folder, on Windows PowerShell:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
# Only required for browser mode:
.\.venv\Scripts\python.exe -m playwright install chromium
```

On macOS/Linux use `python3 -m venv .venv` and `.venv/bin/python` in place of the Windows executable. Dependency major versions are bounded; freeze a tested environment for deployment.

## Google Places API

Enable **Places API (New)** and billing in your Google Cloud project, create an API key restricted to that API, and set it in the current process environment. Do not put the key in source control.

```powershell
$env:GOOGLE_MAPS_API_KEY = "YOUR_API_KEY"
.\.venv\Scripts\python.exe cairo_leads.py --backend places --regions "New Cairo" "Nasr City" "Maadi" "Zamalek" --keywords "dentists" "car repair" "beauty salons" --require-phone --output leads.csv
```

The implementation uses Text Search (New), an explicit field mask, and `nextPageToken`. Phone, website, rating and review count fields trigger the Text Search Enterprise billing tier. The default four regions and three example keywords can make up to 36 successful page requests (20 candidates/page and a 60-candidate cap), plus retries. Set billing quotas before scaling. Search is ranked and capped, not an exhaustive directory.

## Playwright

```powershell
.\.venv\Scripts\python.exe cairo_leads.py --backend playwright --headed --stealth --regions "Maadi" "Nasr City" --keywords "plumbers" "electricians" --require-phone --max-results 40 --output leads.csv
```

Browser mode uses an English locale, sequential navigation, random delays, bounded feed scrolling, stable details-panel checks and optional `playwright-stealth` 2.x. The native Chromium user agent is used by default; `--user-agent` accepts an override matching your installed browser. Randomization and stealth cannot guarantee avoiding blocks. Challenges, consent interstitials, HTTP 403 and 429 stop the run; they are not bypassed. Browser runs start in a fresh context. If a consent interstitial blocks the environment, use the API backend.

Maps changes its markup and may vary by account/locale. The browser adapter is a maintenance baseline, not a claim of verified live compatibility. DOM stability reduces incomplete reads but cannot prove that an absent website control means a genuinely missing field. Live-check a small sample before trusting browser output. Browser sub-category stays empty because Maps does not reliably expose a separate structured field. Sub-district is matched against explicit address text; unavailable districts stay empty. API sub-category contains Google's additional type tags, not an invented category hierarchy.

## Filtering and geography

- A lead means **no website listed in the successfully read Google record**. This does not prove the business has no website elsewhere.
- Any listed URL excludes a business, including social profiles and broken sites. No HTTP liveness probe is performed: a timeout or 403 must not become evidence of no website.
- A website detected on any duplicate disqualifies the whole duplicate group. Deduplication is transitive across normalized phone, Place ID and Maps feature identity/URL. Shared chain phone numbers intentionally collapse branches under the requested phone-based rule.
- Valid Egyptian phone numbers are normalized to E.164 (`+20...`), including mobile and Cairo landline numbers. Invalid, missing and short-code numbers produce an empty normalized phone while retaining `phone_raw`. `--require-phone` excludes these records.
- `query_region` records the search target; `sub_district` comes from returned data. Search terms do not guarantee exact neighborhood membership.
- The default bounding box `(29.85, 31.18, 30.20, 31.75)` is an approximate Cairo search envelope and may include neighboring areas. It is not a governorate polygon. Both backends reject coordinates outside it; browser mode skips listings lacking place coordinates. Adjust with `--bbox SOUTH WEST NORTH EAST`. Exact administrative membership would require a separately supplied boundary dataset.
- API permanently closed businesses are excluded. The browser backend does not reliably determine operational status; manually review those candidates.

## Output and failure handling

CSV contains name, category, sub-category, full address, sub-district, normalized/raw phone, website status/URL, rating/review count, Maps URL, Place ID when available, coordinates, query provenance and check timestamp. Unknown ratings/counts stay blank, not zero.

CSV uses UTF-8 BOM for Arabic compatibility and atomic replacement. Text cells beginning with formula operators receive a leading apostrophe for spreadsheet safety, including `+20` phones. For unmodified phone strings use the DataFrame path below. Import CSV phone columns as text.

Completed observations are checkpointed after each query and on handled shutdown. A hard process kill/power loss can lose the current query. Each invocation replaces the output; there is no cross-run resume. A neighboring `leads.summary.json` includes completion state and query/detail failures. Exit codes: `0` completed without recorded errors, `2` partial results, `1` fatal failure, `130` interruption. Feed stalls and incomplete panels are errors, not empty successful searches. Set `--min-delay`, `--max-delay`, `--retries` and `--max-scrolls` as needed. API retry logic handles transient transport errors, HTTP 408/429 and selected 5xx statuses, honoring bounded Retry-After seconds/dates. Other HTTP failures are reported without blind retry.

## Pandas / Google Sheets integration

```python
import asyncio
import os
import httpx
from cairo_leads import PlacesBackend, parse_args, select_leads, to_dataframe

async def dataframe():
    args = parse_args(["--keywords", "dentists", "--regions", "Maadi"])
    async with httpx.AsyncClient(timeout=30, headers={
        "X-Goog-Api-Key": os.environ["GOOGLE_MAPS_API_KEY"],
        "X-Goog-FieldMask": PlacesBackend.FIELD_MASK,
    }) as client:
        backend = PlacesBackend(args, client)
        records = [lead async for lead in backend.search("Maadi", "dentists")]
    return to_dataframe(select_leads(records, require_phone=True))

df = asyncio.run(dataframe())
# Feed these rows to your authorized Sheets client with valueInputOption="RAW".
values = [df.columns.tolist()] + df.astype(object).where(df.notna(), "").values.tolist()
```

No Google Sheets credentials or writes are included. RAW preserves `+20` strings without interpreting them as formulas.

## Tests and validation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Tests use mocked API transport and local records. They do not spend API credits or scrape Google. Live API authentication/billing, live Maps selectors and end-to-end browser extraction require validation in the deployment environment.

## References

- [Google Text Search (New): fields, pagination, bounding boxes and billing tiers](https://developers.google.com/maps/documentation/places/web-service/text-search)
- [Playwright browser contexts and user-agent options](https://playwright.dev/python/docs/api/class-browser)
- [playwright-stealth 2.x API](https://pypi.org/project/playwright-stealth/)
