"""Async Cairo lead extraction. Python 3.11+. See README for limitations."""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import logging
import os
import random
import re
from dataclasses import asdict, dataclass, fields, replace
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlsplit, urlunsplit

import httpx
import phonenumbers

LOG = logging.getLogger("cairo_leads")
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
# Approximate Cairo envelope, NOT an administrative boundary. Override via CLI.
DEFAULT_BBOX = (29.85, 31.18, 30.20, 31.75)


class ExtractionError(RuntimeError):
    pass


class Blocked(ExtractionError):
    pass


def normalize_phone(raw: str) -> str:
    """Only valid Egyptian numbers become E.164 identifiers; preserve raw separately."""
    raw = raw.translate(DIGITS).strip()
    raw = re.sub(r"^(?:Phone|Telephone):\s*", "", raw, flags=re.I)
    if re.fullmatch(r"20\d{9,10}", re.sub(r"[\s()-]", "", raw)):
        raw = "+" + raw
    try:
        number = phonenumbers.parse(raw, "EG")
        if number.country_code == 20 and phonenumbers.is_valid_number(number):
            return phonenumbers.format_number(number, phonenumbers.PhoneNumberFormat.E164)
    except phonenumbers.NumberParseException:
        pass
    return ""


def canonical_url(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc.lower(), parts.path.rstrip("/"), "", ""))


def address_district(address: str, region: str) -> str:
    """Conservative browser fallback: return a district only when present in address."""
    candidates = [region, "New Cairo", "Nasr City", "Maadi", "Zamalek", "Heliopolis",
                  "القاهرة الجديدة", "مدينة نصر", "المعادي", "الزمالك", "مصر الجديدة"]
    for candidate in candidates:
        match = re.search(r"(?<!\w)" + re.escape(candidate) + r"(?!\w)", address, re.I)
        if match:
            return match[0]
    return ""


def url_identity(url: str) -> str:
    """Do not mistake the !1s Maps feature ID for an official Places API ID."""
    parts = urlsplit(url)
    query = parse_qs(parts.query)
    for key in ("query_place_id", "cid", "ftid"):
        if query.get(key):
            return f"{key}:{query[key][0]}"
    match = re.search(r"!1s([^!/?]+)", unquote(url))
    return "feature:" + match[1] if match else canonical_url(url)


@dataclass
class Lead:
    business_name: str = ""
    category: str = ""
    sub_category: str = ""
    full_address: str = ""
    sub_district: str = ""
    phone: str = ""
    phone_raw: str = ""
    website_status: str = "unknown"
    website: str = ""
    rating: float | None = None
    review_count: int | None = None
    google_maps_url: str = ""
    place_id: str = ""
    latitude: float | None = None
    longitude: float | None = None
    query_region: str = ""
    query_keyword: str = ""
    source: str = ""
    checked_at: str = ""


def in_bbox(lat: float | None, lon: float | None, bbox: tuple) -> bool:
    return lat is not None and lon is not None and bbox[0] <= lat <= bbox[2] and bbox[1] <= lon <= bbox[3]


def select_leads(records: list[Lead], require_phone: bool = False,
                 only_no_website: bool = True) -> list[Lead]:
    """Union all identities, including website-bearing records, before filtering.

    A late duplicate bridging two groups cannot leak a second lead. A website
    found on any member conservatively disqualifies the entire group.
    """
    parent = list(range(len(records)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    seen = {}
    for i, lead in enumerate(records):
        keys = []
        if lead.phone:
            keys.append(("phone", lead.phone))
        if lead.place_id:
            keys.append(("place", lead.place_id))
        if lead.google_maps_url:
            keys.append(("url", url_identity(lead.google_maps_url)))
        for key in keys:
            if key in seen:
                parent[root(i)] = root(seen[key])
            seen[key] = i
    groups = {}
    for i, lead in enumerate(records):
        groups.setdefault(root(i), []).append(lead)
    result = []
    for group in groups.values():
        listed = next((x for x in group if x.website.strip() or x.website_status == "listed"), None)
        unknown = any(x.website_status not in ("missing", "listed") for x in group)
        if only_no_website and (listed or unknown):
            continue
        eligible = [x for x in group if x.business_name and x.full_address and
                    x.google_maps_url and (x.phone or not require_phone)]
        if eligible:
            chosen = max(eligible, key=lambda x: (bool(x.phone), x.review_count or 0))
            result.append(replace(chosen, website=listed.website if listed else "",
                                  website_status="listed" if listed else "unknown" if unknown else "missing"))
    return sorted(result, key=lambda x: (x.query_region, x.business_name.casefold()))


def to_dataframe(leads: list[Lead]):
    """No file round-trip; phone strings remain intact for Sheets valueInputOption=RAW."""
    import pandas as pd
    return pd.DataFrame([asdict(x) for x in leads], columns=[x.name for x in fields(Lead)])


def csv_cell(value):
    # Protect spreadsheet imports from formula injection; a +20 phone remains text.
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def save_csv(path: Path, leads: list[Lead]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[x.name for x in fields(Lead)])
        writer.writeheader()
        writer.writerows({k: csv_cell(v) for k, v in asdict(x).items()} for x in leads)
    os.replace(temp, path)


async def pause(args):
    await asyncio.sleep(random.uniform(args.min_delay, args.max_delay))


def retry_after(value: str | None) -> float:
    if not value:
        return 0
    try:
        return max(0, float(value))
    except ValueError:
        try:
            return max(0, (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds())
        except (ValueError, TypeError):
            return 0


class PlacesBackend:
    FIELD_MASK = ",".join("places." + x for x in (
        "id", "displayName", "primaryTypeDisplayName", "types", "formattedAddress",
        "addressComponents", "internationalPhoneNumber", "nationalPhoneNumber",
        "websiteUri", "rating", "userRatingCount", "googleMapsUri", "location",
        "businessStatus")) + ",nextPageToken"

    def __init__(self, args, client):
        self.args, self.client = args, client

    async def request(self, body):
        for attempt in range(self.args.retries + 1):
            await pause(self.args)
            delay = 0
            try:
                response = await self.client.post(
                    "https://places.googleapis.com/v1/places:searchText", json=body)
                if response.status_code not in (408, 429, 500, 502, 503, 504):
                    response.raise_for_status()
                    return response.json()
                delay = retry_after(response.headers.get("Retry-After"))
                if delay > 120:
                    raise ExtractionError("Server requests a cooldown over 120s; stop and retry later")
                if attempt == self.args.retries:
                    response.raise_for_status()
            except httpx.TransportError:
                if attempt == self.args.retries:
                    raise
            await asyncio.sleep(max(delay, min(60, 2 ** attempt + random.random())))
        raise ExtractionError("Request retry budget exhausted")

    async def search(self, region, keyword):
        south, west, north, east = self.args.bbox
        body = {"textQuery": f"{keyword} in {region}, Cairo, Egypt", "languageCode": "en",
                "regionCode": "EG", "pageSize": 20,
                "locationRestriction": {"rectangle": {
                    "low": {"latitude": south, "longitude": west},
                    "high": {"latitude": north, "longitude": east}}}}
        count, tokens = 0, set()
        while count < self.args.max_results:
            data = await self.request(body)
            for place in data.get("places", []):
                count += 1
                location = place.get("location", {})
                lat, lon = location.get("latitude"), location.get("longitude")
                if in_bbox(lat, lon, self.args.bbox) and place.get("businessStatus") != "CLOSED_PERMANENTLY":
                    raw = place.get("internationalPhoneNumber") or place.get("nationalPhoneNumber", "")
                    website = (place.get("websiteUri") or "").strip()
                    components = place.get("addressComponents", [])
                    district = next((c.get("longText", "") for kind in (
                        "sublocality_level_2", "sublocality_level_1", "sublocality", "neighborhood")
                        for c in components if kind in c.get("types", [])), "")
                    yield Lead(
                        business_name=place.get("displayName", {}).get("text", ""),
                        category=place.get("primaryTypeDisplayName", {}).get("text", ""),
                        sub_category=" | ".join(place.get("types", [])),
                        full_address=place.get("formattedAddress", ""), sub_district=district,
                        phone=normalize_phone(raw), phone_raw=raw,
                        website_status="listed" if website else "missing", website=website,
                        rating=place.get("rating"), review_count=place.get("userRatingCount"),
                        google_maps_url=place.get("googleMapsUri", ""), place_id=place.get("id", ""),
                        latitude=lat, longitude=lon, query_region=region, query_keyword=keyword,
                        source="places", checked_at=datetime.now(timezone.utc).isoformat())
                if count >= self.args.max_results:
                    break
            token = data.get("nextPageToken")
            if not token:
                break
            if token in tokens:
                raise ExtractionError("Repeated API pagination token")
            tokens.add(token)
            body["pageToken"] = token


class BrowserBackend:
    """DOM adapter: Maps markup is not a stable API; maintain these selectors."""
    def __init__(self, args, context):
        self.args, self.context = args, context
        self.errors = 0

    async def guard(self, page):
        if "/sorry/" in page.url or "consent.google" in page.url or await page.locator(
            'iframe[src*="recaptcha"], form[action*="/sorry/"]').count():
            raise Blocked("Google challenge/consent page encountered; browser run stopped")
        text = (await page.locator("body").inner_text())[:12000].lower()
        if "unusual traffic" in text or "verify you are human" in text:
            raise Blocked("Google traffic challenge encountered; browser run stopped")

    async def navigate(self, page, url):
        from playwright.async_api import TimeoutError as PlaywrightTimeout
        for attempt in range(self.args.retries + 1):
            await pause(self.args)
            try:
                response = await page.goto(url, wait_until="domcontentloaded", timeout=45000)
                await self.guard(page)
                if response and response.status in (403, 429):
                    raise Blocked(f"Google returned HTTP {response.status}")
                if response and response.status >= 400:
                    raise ExtractionError(f"Browser HTTP {response.status}")
                return
            except (PlaywrightTimeout, ExtractionError) as exc:
                if isinstance(exc, Blocked) or attempt == self.args.retries:
                    raise
                await asyncio.sleep(min(60, 2 ** attempt + random.random()))

    async def links(self, page, region, keyword):
        from playwright.async_api import TimeoutError as PlaywrightTimeout
        query = quote(f"{keyword} in {region}, Cairo, Egypt")
        await self.navigate(page, f"https://www.google.com/maps/search/{query}/?hl=en")
        await page.locator('[role="feed"], h1, [role="main"]').first.wait_for(timeout=20000)
        # Search may redirect directly to a single business.
        if "/maps/place/" in page.url:
            return [page.url]
        feed = page.locator('[role="feed"]').first
        try:
            await feed.wait_for(timeout=15000)
        except PlaywrightTimeout:
            await self.guard(page)
            if "No results found" in await page.locator("body").inner_text():
                return []
            raise ExtractionError("Maps result feed did not load")
        links, idle = {}, 0
        for _ in range(self.args.max_scrolls):
            await self.guard(page)
            urls = await feed.locator('a[href*="/maps/place/"]').evaluate_all(
                "nodes => nodes.map(n => n.href)")
            before = len(links)
            for url in urls:
                links.setdefault(url_identity(url), url)
            idle = idle + 1 if len(links) == before else 0
            if len(links) >= self.args.max_results:
                break
            if "You've reached the end of the list" in await feed.inner_text():
                break
            if idle >= 6:
                raise ExtractionError("Result feed stalled before an end marker; retry query")
            await feed.evaluate("node => node.scrollBy(0, node.clientHeight * 0.9)")
            await asyncio.sleep(random.uniform(2, 4))
        else:
            raise ExtractionError("Scroll limit reached before feed completion; increase --max-scrolls")
        return list(links.values())[:self.args.max_results]

    async def details(self, page, url, region, keyword):
        await self.navigate(page, url)
        main = page.locator('[role="main"]').filter(has=page.locator("h1")).first
        await main.locator("h1").wait_for(timeout=20000)
        await main.locator('button[data-item-id="address"]').wait_for(timeout=15000)
        # Require several identical snapshots of a populated details panel. Absence
        # still cannot be proven from DOM; use Places for a stronger field contract.
        previous, stable = None, 0
        for _ in range(12):
            await asyncio.sleep(1)
            await self.guard(page)
            snapshot = await main.inner_text()
            stable = stable + 1 if snapshot == previous else 0
            previous = snapshot
            if stable >= 3 and not await main.locator('[aria-busy="true"]').count():
                break
        else:
            raise ExtractionError("Unstable business panel; website status unknown")

        async def attr(selector, name):
            element = main.locator(selector).first
            return (await element.get_attribute(name) or "") if await element.count() else ""

        website_element = main.locator('[data-item-id="authority"], a[aria-label^="Website:"]')
        has_website = bool(await website_element.count())
        website = (await website_element.first.get_attribute("href") or "") if has_website else ""
        address = re.sub(r"^Address:\s*", "", await attr('button[data-item-id="address"]', "aria-label"))
        phone_raw = re.sub(r"^Phone:\s*", "", await attr('button[data-item-id^="phone:tel:"]', "aria-label"))
        category_node = main.locator('button[jsaction*="category"]').first
        category = await category_node.inner_text() if await category_node.count() else ""
        rating_label = await attr('[role="img"][aria-label*="stars"]', "aria-label")
        rating_match = re.search(r"([0-5](?:[.,]\d+)?)\s+stars", rating_label)
        review_label = await attr('button[aria-label*="reviews"]', "aria-label")
        reviews = re.search(r"([\d,]+)\s+reviews", review_label)
        # !3d/!4d describe the selected place; /@ describes the camera, not the place.
        coords = re.search(r"!3d(-?[\d.]+)!4d(-?[\d.]+)", page.url)
        lat, lon = (float(coords[1]), float(coords[2])) if coords else (None, None)
        if not in_bbox(lat, lon, self.args.bbox):
            raise ExtractionError("Place coordinates missing or outside configured Cairo envelope")
        return Lead(
            business_name=(await main.locator("h1").first.inner_text()).strip(),
            category=category, full_address=address, sub_district=address_district(address, region),
            phone=normalize_phone(phone_raw), phone_raw=phone_raw,
            website_status="listed" if has_website else "missing", website=website,
            rating=float(rating_match[1].replace(",", ".")) if rating_match else None,
            review_count=int(reviews[1].replace(",", "")) if reviews else None,
            google_maps_url=page.url, latitude=lat, longitude=lon,
            query_region=region, query_keyword=keyword, source="playwright",
            checked_at=datetime.now(timezone.utc).isoformat())

    async def search(self, region, keyword):
        from playwright.async_api import TimeoutError as PlaywrightTimeout
        page = await self.context.new_page()
        try:
            urls = await self.links(page, region, keyword)
            for url in urls:
                for attempt in range(self.args.retries + 1):
                    try:
                        yield await self.details(page, url, region, keyword)
                        break
                    except Blocked:
                        raise
                    except (ExtractionError, PlaywrightTimeout) as exc:
                        if attempt == self.args.retries:
                            self.errors += 1
                            LOG.warning("Skipped detail (%s): %s", type(exc).__name__, url)
                        else:
                            await asyncio.sleep(2 ** attempt + random.random())
        finally:
            await page.close()


async def collect(args, backend):
    records, errors = [], []
    completed = False
    try:
        for region in args.regions:
            for keyword in args.keywords:
                LOG.info("Searching %s / %s", region, keyword)
                try:
                    async for lead in backend.search(region, keyword):
                        records.append(lead)
                except Blocked:
                    raise
                except (httpx.HTTPError, ExtractionError) as exc:
                    errors.append({"region": region, "keyword": keyword, "error": type(exc).__name__})
                    LOG.error("Query failed: %s", exc)
                finally:
                    save_csv(args.output, select_leads(records, args.require_phone))
        completed = True
    finally:
        leads = select_leads(records, args.require_phone)
        save_csv(args.output, leads)
        summary = {"completed": completed, "observations": len(records), "leads": len(leads), "query_errors": errors,
                   "detail_errors": getattr(backend, "errors", 0),
                   "finished_at": datetime.now(timezone.utc).isoformat()}
        args.output.with_suffix(".summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        LOG.info("Saved %d leads to %s", len(leads), args.output)
    return 2 if errors or getattr(backend, "errors", 0) else 0


async def run(args):
    if args.backend == "places":
        key = os.environ.get("GOOGLE_MAPS_API_KEY")
        if not key:
            raise ExtractionError("Set GOOGLE_MAPS_API_KEY with Places API (New) enabled")
        async with httpx.AsyncClient(timeout=httpx.Timeout(30), headers={
            "X-Goog-Api-Key": key, "X-Goog-FieldMask": PlacesBackend.FIELD_MASK}) as client:
            return await collect(args, PlacesBackend(args, client))
    from playwright.async_api import async_playwright
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=not args.headed)
        try:
            options = {"locale": "en-US", "timezone_id": "Africa/Cairo",
                       "viewport": {"width": 1440, "height": 1000}}
            if args.user_agent:
                options["user_agent"] = args.user_agent
            context = await browser.new_context(**options)
            if args.stealth:
                from playwright_stealth import Stealth
                await Stealth().apply_stealth_async(context)
            return await collect(args, BrowserBackend(args, context))
        finally:
            await browser.close()


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=["places", "playwright"], default="places")
    parser.add_argument("--regions", nargs="+", default=["New Cairo", "Nasr City", "Maadi", "Zamalek"])
    parser.add_argument("--keywords", nargs="+", required=True)
    parser.add_argument("--output", type=Path, default=Path("cairo_leads.csv"))
    parser.add_argument("--bbox", nargs=4, type=float, default=DEFAULT_BBOX, metavar=("S", "W", "N", "E"))
    parser.add_argument("--max-results", type=int, default=60, help="Candidate cap per region/keyword, before filtering")
    parser.add_argument("--max-scrolls", type=int, default=100)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--min-delay", type=float, default=2)
    parser.add_argument("--max-delay", type=float, default=5)
    parser.add_argument("--require-phone", action="store_true")
    parser.add_argument("--headed", action="store_true")
    parser.add_argument("--stealth", action="store_true")
    parser.add_argument("--user-agent", help="Optional UA matching your installed browser; default is native Chromium UA")
    args = parser.parse_args(argv)
    if not (0 <= args.min_delay <= args.max_delay <= 120):
        parser.error("Delays must satisfy 0 <= min <= max <= 120")
    if not (0 <= args.retries <= 10) or args.max_results < 1 or args.max_scrolls < 1:
        parser.error("Use 0..10 retries and positive result/scroll limits")
    s, w, n, e = args.bbox
    if not (-90 <= s < n <= 90 and -180 <= w < e <= 180):
        parser.error("Invalid bounding box")
    return args


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    try:
        return asyncio.run(run(parse_args()))
    except KeyboardInterrupt:
        LOG.warning("Interrupted; completed observations saved if collection started")
        return 130
    except Exception as exc:
        LOG.error("Run stopped (%s): %s", type(exc).__name__, exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
