"""Local dashboard. Launch: python -m streamlit run app.py --server.address 127.0.0.1"""
from __future__ import annotations

import asyncio
import csv
import io
import os
import re
import sys
import threading
from collections import deque
from dataclasses import asdict, fields
from datetime import datetime
from types import SimpleNamespace

import httpx
import streamlit as st
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

from cairo_leads import (
    Blocked, BrowserBackend, ExtractionError, Lead, PlacesBackend,
    csv_cell, select_leads, to_dataframe,
)

DISTRICTS = ["New Cairo", "Maadi", "Nasr City", "Sheikh Zayed", "Zamalek", "Dokki", "Heliopolis"]
NICHES = ["Dental Clinics", "Dermatology", "Fine Dining", "Gyms", "Furniture"]
# Greater Cairo envelope includes western districts requested by the dashboard.
GREATER_CAIRO_BBOX = (29.85, 30.85, 30.25, 31.80)


def combine_choices(selected, custom):
    """Accept comma/newline-separated entries, deduplicated without losing order."""
    result, seen = [], set()
    for value in [*selected, *re.split(r"[,\n]", custom)]:
        value = value.strip()
        if value and value.casefold() not in seen:
            seen.add(value.casefold())
            result.append(value)
    return result


def export_csv(records: list[Lead]) -> bytes:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=[f.name for f in fields(Lead)])
    writer.writeheader()
    writer.writerows({key: csv_cell(value) for key, value in asdict(row).items()} for row in records)
    return buffer.getvalue().encode("utf-8-sig")


def export_excel(records: list[Lead]) -> bytes:
    """Explicit text cells preserve +20 numbers and never create spreadsheet formulas."""
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Leads"
    sheet.append([f.name for f in fields(Lead)])
    for row_index, record in enumerate(records, 2):
        for col_index, value in enumerate(asdict(record).values(), 1):
            cell = sheet.cell(row_index, col_index, value)
            if isinstance(value, str):
                cell.data_type = "s"
                cell.number_format = "@"
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="163D35")
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    for column in sheet.columns:
        letter = column[0].column_letter
        sheet.column_dimensions[letter].width = min(55, max(18, len(str(column[0].value)) + 3))
    buffer = io.BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


class ScrapeJob:
    """One worker per Streamlit session. The worker never calls Streamlit APIs.

    A lock protects shared observations; an asyncio watcher cancels in-flight
    requests and lets the backend close its browser/client before reporting done.
    """
    def __init__(self, args, api_key=""):
        self.args = args
        self._key = api_key
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._records = []
        self._logs = deque(maxlen=150)
        self._status = "running"
        self._current = "Starting…"
        self._completed = 0
        self._errors = 0
        self.total = len(args.regions) * len(args.keywords)
        self.thread = threading.Thread(target=self._worker, daemon=True, name="cairo-scraper")

    def start(self):
        self.thread.start()

    def stop(self):
        self._stop.set()

    def snapshot(self):
        with self._lock:
            return dict(records=list(self._records), logs=list(self._logs), status=self._status,
                        current=self._current, completed=self._completed, errors=self._errors,
                        total=self.total, stopping=self._stop.is_set())

    def log(self, message):
        # Do not persist secrets or full HTTP exception bodies in browser output.
        if self._key:
            message = message.replace(self._key, "[redacted]")
        with self._lock:
            self._logs.append(f"{datetime.now():%H:%M:%S}  {message}")

    async def _queries(self, backend):
        for region in self.args.regions:
            for keyword in self.args.keywords:
                if self._stop.is_set():
                    raise asyncio.CancelledError
                with self._lock:
                    self._current = f"{region} / {keyword}"
                self.log(f"Searching {region} / {keyword}")
                before = getattr(backend, "errors", 0)
                try:
                    async for record in backend.search(region, keyword):
                        with self._lock:
                            self._records.append(record)
                except Blocked:
                    raise
                except (httpx.HTTPError, ExtractionError) as exc:
                    with self._lock:
                        self._errors += 1
                    code = f" HTTP {exc.response.status_code}" if isinstance(exc, httpx.HTTPStatusError) else ""
                    self.log(f"Query failed: {type(exc).__name__}{code}. Continuing.")
                finally:
                    skipped = getattr(backend, "errors", 0) - before
                    with self._lock:
                        self._errors += skipped
                    if skipped:
                        self.log(f"Skipped {skipped} incomplete business details.")
                with self._lock:
                    self._completed += 1
                self.log("Query finished.")

    async def _scrape(self):
        if self.args.backend == "places":
            async with httpx.AsyncClient(timeout=30, headers={
                "X-Goog-Api-Key": self._key, "X-Goog-FieldMask": PlacesBackend.FIELD_MASK,
            }) as client:
                await self._queries(PlacesBackend(self.args, client))
            return
        from playwright.async_api import async_playwright
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=not self.args.headed)
            try:
                context = await browser.new_context(locale="en-US", timezone_id="Africa/Cairo",
                                                    viewport={"width": 1440, "height": 1000})
                if self.args.stealth:
                    from playwright_stealth import Stealth
                    await Stealth().apply_stealth_async(context)
                await self._queries(BrowserBackend(self.args, context))
            finally:
                await browser.close()

    async def _watch_cancel(self, task):
        while not task.done():
            if self._stop.is_set():
                task.cancel()
                return
            await asyncio.sleep(0.2)

    async def _execute(self):
        task = asyncio.create_task(self._scrape())
        watcher = asyncio.create_task(self._watch_cancel(task))
        try:
            await task
        finally:
            watcher.cancel()
            await asyncio.gather(watcher, return_exceptions=True)

    def _worker(self):
        status = "complete"
        try:
            # Streamlit may use a Selector loop on Windows; Playwright needs subprocess support.
            factory = asyncio.ProactorEventLoop if sys.platform == "win32" else asyncio.new_event_loop
            with asyncio.Runner(loop_factory=factory) as runner:
                runner.run(self._execute())
            if self._errors:
                status = "partial"
            self.log("Run finished. Results are ready to export.")
        except asyncio.CancelledError:
            status = "cancelled"
            self.log("Cancelled. Completed observations remain available.")
        except Blocked:
            status = "failed"
            self.log("Google challenge or access block detected. Run stopped.")
        except Exception as exc:
            status = "failed"
            self.log(f"Run failed ({type(exc).__name__}). Check setup, API access, or browser installation.")
        finally:
            self._key = ""
            with self._lock:
                self._status = status


def main():
    st.set_page_config(page_title="Cairo / Lead Studio", page_icon="◉", layout="wide")
    st.markdown("""<style>
      .block-container {max-width:1400px;padding-top:2.5rem;}
      h1 {letter-spacing:-.065em;font-weight:650 !important;}
      [data-testid="stMetric"] {border:1px solid #dce4df;border-radius:12px;padding:18px;}
      [data-testid="stMetricValue"] {font-variant-numeric:tabular-nums;}
      div.stButton > button[kind="primary"] {border-radius:8px;}
    </style>""", unsafe_allow_html=True)
    job = st.session_state.get("scrape_job")
    running = bool(job and job.snapshot()["status"] == "running")
    with st.sidebar:
        st.caption("CAIRO / LEAD STUDIO")
        st.subheader("Build a search")
        backend_label = st.radio("Source", ["Google Places API", "Playwright"], disabled=running)
        backend = "places" if backend_label == "Google Places API" else "playwright"
        key = ""
        headed = stealth = False
        if backend == "places":
            key = st.text_input("Google Places API key", type="password", disabled=running,
                                help="Leave empty to use GOOGLE_MAPS_API_KEY from your environment.")
            st.caption("Places API (New) and billing must be enabled.")
        else:
            headed = st.checkbox("Show browser (headed)", disabled=running)
            stealth = st.checkbox("Enable optional stealth", disabled=running)
        regions = st.multiselect("Districts", DISTRICTS, default=["Maadi", "Nasr City"], disabled=running)
        custom_regions = st.text_input("Other districts", placeholder="Garden City, Mokattam", disabled=running)
        keywords = st.multiselect("Business categories", NICHES, default=["Dental Clinics"], disabled=running)
        custom_keywords = st.text_input("Other categories", placeholder="Florists, Car repair", disabled=running)
        cap = st.slider("Candidates per query", 10, 60 if backend == "places" else 200, 40, 10, disabled=running)
        st.caption("Candidate cap applies before filtering. Each district × category is one query.")
        with st.expander("Request pacing"):
            delays = st.slider("Delay range (seconds)", 1, 15, (2, 5), disabled=running)
            retries = st.number_input("Retries", min_value=0, max_value=5, value=3, disabled=running)
        st.caption("Search covers Greater Cairo, including Dokki and Sheikh Zayed. Boundaries are approximate.")

    st.caption("LOCAL BUSINESS INTELLIGENCE")
    st.title("Find the next conversation.")
    st.write("Explore Cairo businesses. Keep the leads that fit.")
    filter_left, filter_right = st.columns(2)
    require_phone = filter_left.checkbox("Require Phone Number", value=True)
    only_no_website = filter_right.checkbox("Only No Website", value=True)
    st.caption("No website means no website listed on Maps. Phone verification checks number format, not reachability.")

    regions = combine_choices(regions, custom_regions)
    keywords = combine_choices(keywords, custom_keywords)
    cols = st.columns([1, 3])
    if cols[0].button("Start Scraping", type="primary", disabled=running, width="stretch"):
        api_key = key.strip() or os.environ.get("GOOGLE_MAPS_API_KEY", "")
        if not regions or not keywords:
            st.error("Choose at least one district and one business category.")
        elif backend == "places" and not api_key:
            st.error("Enter a Google Places API key in the sidebar.")
        elif len(regions) * len(keywords) > 100:
            st.error("Limit each run to 100 district/category combinations.")
        else:
            args = SimpleNamespace(backend=backend, regions=regions, keywords=keywords,
                                   bbox=GREATER_CAIRO_BBOX, max_results=cap, max_scrolls=100,
                                   retries=int(retries), min_delay=delays[0], max_delay=delays[1],
                                   headed=headed, stealth=stealth)
            job = ScrapeJob(args, api_key)
            st.session_state.scrape_job = job
            job.start()
            st.rerun()
    cols[1].caption(f"{len(regions) * len(keywords)} queries · Up to {len(regions) * len(keywords) * cap:,} candidates")

    @st.fragment(run_every=1 if running else None)
    def results():
        current_job = st.session_state.get("scrape_job")
        snapshot = current_job.snapshot() if current_job else None
        if running and snapshot and snapshot["status"] != "running":
            st.rerun()  # Re-enable sidebar controls and stop automatic polling.
        records = snapshot["records"] if snapshot else []
        all_leads = select_leads(records, only_no_website=False)
        missing = select_leads(records)
        visible = select_leads(records, require_phone, only_no_website)
        a, b, c = st.columns(3)
        a.metric("Total Scraped", len(all_leads), help="Unique businesses after deduplication, before display filters.")
        b.metric("Leads Without Website", len(missing))
        c.metric("Verified Phone Numbers", sum(bool(row.phone) for row in all_leads),
                 help="Valid Egyptian phone format; not a live call or ownership check.")
        if snapshot:
            fraction = snapshot["completed"] / max(1, snapshot["total"])
            st.progress(fraction, text=f"{snapshot['completed']} / {snapshot['total']} queries · {snapshot['current']}")
            if snapshot["status"] == "running":
                if st.button("Stop / Cancel", disabled=snapshot["stopping"]):
                    current_job.stop()
                    st.rerun(scope="fragment")
                if snapshot["stopping"]:
                    st.info("Stopping and closing connections…")
            elif snapshot["status"] == "complete":
                st.success("Run complete.")
            elif snapshot["status"] == "cancelled":
                st.warning("Run cancelled. Partial results are available below.")
            elif snapshot["status"] == "partial":
                st.warning(f"Finished with {snapshot['errors']} errors. Review the activity log.")
            else:
                st.error("Run stopped with an error. Any collected results remain available.")
            with st.expander("Live activity", expanded=snapshot["status"] == "running"):
                st.code("\n".join(snapshot["logs"]) or "Starting…", language=None)
        st.subheader("Your shortlist")
        st.caption(f"{len(visible):,} matching leads · Filters apply to the table and both downloads.")
        if visible:
            frame = to_dataframe(visible)
            st.dataframe(frame, hide_index=True, width="stretch",
                         column_order=["business_name", "category", "phone", "sub_district", "query_region",
                                       "rating", "review_count", "website_status", "google_maps_url"],
                         column_config={
                             "business_name": "Business Name", "category": "Category", "phone": "Phone",
                             "sub_district": "District", "query_region": "Search District",
                             "rating": st.column_config.NumberColumn("Rating", format="%.1f"),
                             "review_count": "Reviews", "website_status": "Website",
                             "google_maps_url": st.column_config.LinkColumn("Google Maps", display_text="Open listing"),
                         })
            if snapshot and snapshot["status"] == "running":
                st.caption("Downloads become available when the run finishes or is cancelled.")
                return
            left, right, _ = st.columns([1, 1, 2])
            # Downloads are snapshots; no disk writes or shared cross-session output paths.
            left.download_button("Download CSV", export_csv(visible), "cairo_leads.csv", "text/csv",
                                 width="stretch")
            right.download_button("Download Excel", export_excel(visible), "cairo_leads.xlsx",
                                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                  width="stretch")
        else:
            st.info("Your matching leads will appear here. Start a search or adjust the filters.")
    results()


if __name__ == "__main__":
    main()
