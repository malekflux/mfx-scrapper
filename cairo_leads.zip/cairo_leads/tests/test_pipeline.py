import asyncio
import csv
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx

from cairo_leads import (
    Lead, PlacesBackend, address_district, collect, in_bbox, normalize_phone,
    parse_args, retry_after, save_csv, select_leads, to_dataframe, url_identity,
)


def lead(**kwargs):
    base = Lead(business_name="Shop", full_address="Maadi, Cairo",
                google_maps_url="https://www.google.com/maps/place/Shop/data=!1sabc",
                website_status="missing")
    return replace(base, **kwargs)


class DataTests(unittest.TestCase):
    def test_phone_variants(self):
        for raw in ("01012345678", "+20 10 1234 5678", "00201012345678",
                    "٢٠١٠١٢٣٤٥٦٧٨", "٠١٠١٢٣٤٥٦٧٨"):
            self.assertEqual(normalize_phone(raw), "+201012345678")
        self.assertEqual(normalize_phone("02 2345 6789"), "+20223456789")
        for raw in ("", "123", "+1 202 555 0123", "not supplied"):
            self.assertEqual(normalize_phone(raw), "")

    def test_transitive_dedup_and_website_conflict(self):
        a = lead(place_id="A", phone="+201012345678", google_maps_url="https://maps.google.com/A")
        b = lead(place_id="B", phone="+201112345678", google_maps_url="https://maps.google.com/B")
        bridge = replace(a, place_id="B", google_maps_url=b.google_maps_url)
        self.assertEqual(len(select_leads([a, b, bridge])), 1)
        listed = replace(b, website="https://example.com", website_status="listed")
        self.assertEqual(select_leads([a, b, bridge, listed]), [])

    def test_missing_unknown_and_phone_requirement(self):
        self.assertEqual(len(select_leads([lead()])), 1)
        self.assertEqual(select_leads([lead()], require_phone=True), [])
        self.assertEqual(select_leads([lead(website_status="unknown")] ), [])
        self.assertEqual(select_leads([lead(website_status="listed")] ), [])

    def test_url_identity_keeps_query_identifiers(self):
        self.assertNotEqual(url_identity("https://maps.google.com/?cid=1"),
                            url_identity("https://maps.google.com/?cid=2"))
        self.assertEqual(url_identity("https://www.google.com/maps/place/A/data=!1sabc!3d30?hl=en"),
                         url_identity("https://www.google.com/maps/place/B/data=!1sabc!3d31"))

    def test_csv_and_dataframe(self):
        record = lead(business_name="=malicious()", phone="+201012345678")
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "leads.csv"
            save_csv(output, [record])
            with output.open(encoding="utf-8-sig", newline="") as handle:
                row = next(csv.DictReader(handle))
            self.assertEqual(row["phone"], "'+201012345678")
            self.assertEqual(row["business_name"], "'=malicious()")
            self.assertEqual(row["rating"], "")
        self.assertEqual(to_dataframe([record]).iloc[0]["phone"], "+201012345678")
        self.assertIn("phone", to_dataframe([]).columns)

    def test_geography_and_district_not_invented(self):
        self.assertTrue(in_bbox(30.0, 31.3, (29.8, 31.1, 30.2, 31.7)))
        self.assertFalse(in_bbox(None, None, (29.8, 31.1, 30.2, 31.7)))
        self.assertEqual(address_district("Somewhere, Cairo", "Maadi"), "")
        self.assertEqual(address_district("Street, Maadi, Cairo", "Maadi"), "Maadi")
        self.assertEqual(retry_after("3"), 3)
        self.assertEqual(retry_after("invalid"), 0)


class ApiTests(unittest.IsolatedAsyncioTestCase):
    def args(self):
        return parse_args(["--regions", "Maadi", "--keywords", "dentists",
                           "--min-delay", "0", "--max-delay", "0"])

    async def test_pagination_and_exclusion(self):
        calls = []
        def handler(request):
            import json
            body = json.loads(request.content)
            calls.append(body)
            item = {"id": "A" if len(calls) == 1 else "B",
                    "displayName": {"text": "Dentist"}, "formattedAddress": "Maadi, Cairo",
                    "location": {"latitude": 30.0, "longitude": 31.3},
                    "googleMapsUri": "https://maps.google.com/?cid=" + str(len(calls)),
                    "nationalPhoneNumber": "01012345678"}
            if len(calls) == 1:
                return httpx.Response(200, json={"places": [item], "nextPageToken": "next"})
            item["websiteUri"] = "https://example.com"
            return httpx.Response(200, json={"places": [item]})
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            records = [x async for x in PlacesBackend(self.args(), client).search("Maadi", "dentists")]
        self.assertEqual(len(records), 2)
        self.assertEqual(calls[1].pop("pageToken"), "next")
        self.assertEqual(calls[0], calls[1])
        self.assertEqual(select_leads(records), [])  # Shared phone + website disqualifies group.

    async def test_retry_transient_but_not_auth_failure(self):
        responses = iter([httpx.Response(429, headers={"Retry-After": "1"}),
                          httpx.Response(200, json={})])
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda _: next(responses))) as client:
            with patch("cairo_leads.asyncio.sleep", new_callable=AsyncMock) as sleep:
                self.assertEqual(await PlacesBackend(self.args(), client).request({}), {})
                self.assertTrue(any(call.args[0] >= 1 for call in sleep.call_args_list))
        calls = []
        def denied(request):
            calls.append(request)
            return httpx.Response(403)
        async with httpx.AsyncClient(transport=httpx.MockTransport(denied)) as client:
            with self.assertRaises(httpx.HTTPStatusError):
                await PlacesBackend(self.args(), client).request({})
        self.assertEqual(len(calls), 1)

    async def test_checkpoint_after_fatal_error(self):
        class FailingBackend:
            async def search(self, *_):
                yield lead()
                raise RuntimeError("Simulated crash")
        with tempfile.TemporaryDirectory() as directory:
            args = self.args()
            args.output = Path(directory) / "leads.csv"
            with self.assertRaises(RuntimeError):
                await collect(args, FailingBackend())
            import json
            summary = json.loads(args.output.with_suffix(".summary.json").read_text())
            self.assertFalse(summary["completed"])
            self.assertEqual(summary["leads"], 1)
            self.assertTrue(args.output.exists())


if __name__ == "__main__":
    unittest.main()
