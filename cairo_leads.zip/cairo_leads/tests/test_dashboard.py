import asyncio
import io
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from openpyxl import load_workbook
from streamlit.testing.v1 import AppTest

from app import ScrapeJob, combine_choices, export_csv, export_excel
from cairo_leads import Lead, select_leads


def record(**values):
    return Lead(**dict(business_name="=SUM(1,2)", full_address="Maadi, Cairo",
                       google_maps_url="https://maps.google.com/?cid=1", phone="+201012345678",
                       website_status="missing", **values))


class DashboardTests(unittest.TestCase):
    def test_choices_and_optional_website_filter(self):
        self.assertEqual(combine_choices(["Maadi"], "maadi, Dokki\nZamalek"), ["Maadi", "Dokki", "Zamalek"])
        listed = record(website="https://example.com")
        self.assertEqual(select_leads([listed]), [])
        self.assertEqual(select_leads([listed], only_no_website=False)[0].website_status, "listed")

    def test_excel_is_text_not_formula(self):
        workbook = load_workbook(io.BytesIO(export_excel([record()])))
        sheet = workbook.active
        self.assertEqual(sheet["A2"].data_type, "s")
        self.assertEqual(sheet["A2"].value, "=SUM(1,2)")
        self.assertEqual(sheet["F2"].value, "+201012345678")
        self.assertEqual(sheet["F2"].data_type, "s")
        self.assertTrue(export_csv([record()]).startswith(b"\xef\xbb\xbf"))

    def test_background_cancel_preserves_records(self):
        args = SimpleNamespace(regions=["Maadi"], keywords=["Dentist"])
        async def fake_scrape(job):
            with job._lock:
                job._records.append(record())
            await asyncio.sleep(60)
        with patch.object(ScrapeJob, "_scrape", fake_scrape):
            job = ScrapeJob(args, "private-key")
            job.start()
            # Wait for worker initialization without depending on network timings.
            import time
            deadline = time.monotonic() + 5
            while not job.snapshot()["records"] and time.monotonic() < deadline:
                time.sleep(0.01)
            job.stop()
            job.thread.join(timeout=5)
        self.assertFalse(job.thread.is_alive())
        self.assertEqual(job.snapshot()["status"], "cancelled")
        self.assertEqual(len(job.snapshot()["records"]), 1)
        self.assertEqual(job._key, "")

    def test_ui_initial_render_and_validation(self):
        dashboard = AppTest.from_file(str(Path(__file__).parents[1] / "app.py")).run(timeout=15)
        self.assertFalse(dashboard.exception)
        self.assertEqual([m.value for m in dashboard.metric], ["0", "0", "0"])
        with patch.dict("os.environ", {"GOOGLE_MAPS_API_KEY": ""}):
            dashboard.button[0].click().run()
        self.assertIn("Enter a Google Places API key", dashboard.error[0].value)
        self.assertFalse(dashboard.exception)

    def test_ui_results_and_filter_toggle(self):
        dashboard = AppTest.from_file(str(Path(__file__).parents[1] / "app.py"))
        job = ScrapeJob(SimpleNamespace(regions=["Maadi"], keywords=["Dentists"]))
        job._records = [record(website="https://example.com")]
        job._status = "complete"
        job._completed = 1
        dashboard.session_state["scrape_job"] = job
        dashboard.run(timeout=15)
        self.assertFalse(dashboard.exception)
        self.assertEqual(dashboard.metric[0].value, "1")
        self.assertEqual(len(dashboard.dataframe), 0)
        next(x for x in dashboard.checkbox if x.label == "Only No Website").uncheck().run()
        self.assertFalse(dashboard.exception)
        self.assertEqual(len(dashboard.dataframe[0].value), 1)


if __name__ == "__main__":
    unittest.main()
